//
//  ProfileTableController.swift
//  RenewinTask
//
//  Created by brn.developers on 5/14/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit

class ProfileTableController: UITableViewController,UICollectionViewDelegate,UICollectionViewDataSource {
 var items=["Balance","Order","Coupon"]
    var amounts=["Rs.500","46","5"]
    var addressArr=["Address","Messages","Security"]
    

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
        
    }
   
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section==0
        {
            return "Profile"
        }
        return ""
    }
   
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section==0
        {
        if indexPath.row==0
        {
            return 277
        }
        else if indexPath.row==1
        {
            return 111
        }
        }
        
        else if indexPath.section==1
        {
            return 73
        }
        else if indexPath.section==2
        {
            return 73
        }
        return 0
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
      
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section==0
        {
        return 2
        }
        if section==1
        {
            return 3
        }
        if section==2
        {
            return 1
        }
        return 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=UITableViewCell()
        if indexPath.section==0
        {
        if indexPath.row==0
        {
        let cell = tableView.dequeueReusableCell(withIdentifier: "pictureCell", for: indexPath)
            return cell
        }
        if indexPath.row==1
        {
            let cell=tableView.dequeueReusableCell(withIdentifier: "collectionCell2") as! CollectionTableViewCell2
            cell.secondCollection.delegate=self
            cell.secondCollection.dataSource=self
            
            return cell
        }
        }
        if indexPath.section==1
        {
            let cell=tableView.dequeueReusableCell(withIdentifier: "addressCell", for: indexPath) as! AddressTableViewCell
            cell.address.text=addressArr[indexPath.row]
            return cell
        }
        if indexPath.section==2
        {
             let cell=tableView.dequeueReusableCell(withIdentifier: "addressCell", for: indexPath) as! AddressTableViewCell
              cell.address.text="Setting"
            return cell
        }
        
        // Configure the cell...

        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "priceCell", for: indexPath) as! LabelCollectionCell
        
        cell.amountLabel.text=amounts[indexPath.row]
        cell.itemsLabel.text=items[indexPath.row]
        
        return cell
    }
    
    
}
