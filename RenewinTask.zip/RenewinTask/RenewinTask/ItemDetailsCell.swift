//
//  ItemDetailsCell.swift
//  RenewinTask
//
//  Created by brn.developers on 5/14/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit

class ItemDetailsCell: UITableViewCell {

    @IBOutlet weak var noOfItems: UILabel!
    @IBOutlet weak var itemCost: UILabel!
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var itemImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func deleteBtnAcn(_ sender: Any) {
        if Int(noOfItems.text!) != 0
        {
        noOfItems.text=String(Int(noOfItems.text!)!-1)
        }
    }
    @IBAction func addBtnAcn(_ sender: Any) {
        noOfItems.text=String(Int(noOfItems.text!)!+1)
    }
}
