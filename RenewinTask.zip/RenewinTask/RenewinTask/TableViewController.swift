//
//  TableViewController.swift
//  RenewinTask
//
//  Created by brn.developers on 5/14/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController,UICollectionViewDelegate,UICollectionViewDataSource {
   let imagesArr=[#imageLiteral(resourceName: "BestaPizza"),#imageLiteral(resourceName: "chickenPizza"),#imageLiteral(resourceName: "eggPizza"),#imageLiteral(resourceName: "germanchoclatemilkshake"),#imageLiteral(resourceName: "mango"),#imageLiteral(resourceName: "apple"),#imageLiteral(resourceName: "pineapple"),#imageLiteral(resourceName: "recettemilkshake"),#imageLiteral(resourceName: "shake1"),#imageLiteral(resourceName: "strawberrry"),#imageLiteral(resourceName: "Tiramisu"),#imageLiteral(resourceName: "vegPizza")]
    let imagesNames=["BestaPizza","Chicken Pizza","Egg Pizza","German MilkShake","Mango","PineApple","Apple","Recette","Shake","Strawberry","Tiramisu","VegPizza"]
    let imagesCosts=["300","250","200","200","100/kg","150/kg","200/kg","250","200","200/kg","300","150"]
    
    let drinksArr=[#imageLiteral(resourceName: "germanchoclatemilkshake"),#imageLiteral(resourceName: "recettemilkshake"),#imageLiteral(resourceName: "shake1"),#imageLiteral(resourceName: "Tiramisu")]
    let drinkNames=["German MilkShake","Recette","Shake","Tiramisu"]
    let drinkPrices=["200","250","200","300"]
    
    let pizzaArr=[#imageLiteral(resourceName: "BestaPizza"),#imageLiteral(resourceName: "chickenPizza"),#imageLiteral(resourceName: "eggPizza"),#imageLiteral(resourceName: "vegPizza")]
    let pizzaNames=["BestaPizza","Chicken Pizza","Egg Pizza","VegPizza"]
    let pizzaPrices=["300","250","200","200","150"]
    
    let fruitArr=[#imageLiteral(resourceName: "apple"),#imageLiteral(resourceName: "pineapple"),#imageLiteral(resourceName: "mango"),#imageLiteral(resourceName: "strawberrry")]
    let fruitName=["Apple","Pineapple","Mango","Strawberry"]
    let fruitPrice=["200/kg","150/kg","100/kg","200/kg"]
    
    var itemsArray=[#imageLiteral(resourceName: "BestaPizza"),#imageLiteral(resourceName: "chickenPizza"),#imageLiteral(resourceName: "eggPizza"),#imageLiteral(resourceName: "germanchoclatemilkshake"),#imageLiteral(resourceName: "mango"),#imageLiteral(resourceName: "apple"),#imageLiteral(resourceName: "pineapple"),#imageLiteral(resourceName: "recettemilkshake"),#imageLiteral(resourceName: "shake1"),#imageLiteral(resourceName: "strawberrry"),#imageLiteral(resourceName: "Tiramisu"),#imageLiteral(resourceName: "vegPizza")]
    
    var itemNamesArr=["BestaPizza","Chicken Pizza","Egg Pizza","German MilkShake","Mango","PineApple","Apple","Recette","Shake","Strawberry","Tiramisu","VegPizza"]
    var itemCosts=["300","250","200","200","100/kg","150/kg","200/kg","250","200","200/kg","300","150"]
    var labelArr=["All","Drinks","Pizza","Fruits"]
     var ad=UIApplication.shared.delegate as! AppDelegate
   var roundButton = UIButton()
    
    override func viewWillAppear(_ animated: Bool) {
        roundButton.isHidden=false
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        roundButton.frame=CGRect(x:(UIScreen.main.bounds.size.width/2)-40, y: UIScreen.main.bounds.size.height-100, width: 80, height: 80)
        roundButton.backgroundColor=UIColor.black
        roundButton.clipsToBounds=true
        roundButton.layer.cornerRadius=40
        roundButton.setImage(#imageLiteral(resourceName: "dishImage"), for: .normal)
        roundButton.addTarget(self, action: #selector(roundBtnAcn), for: .touchUpInside)
       ad.window?.addSubview(roundButton)
    
    }

    @objc func roundBtnAcn()
    {
        let nextVC=self.storyboard?.instantiateViewController(withIdentifier: "second") as! ProfileTableController
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
   
    override func viewWillDisappear(_ animated: Bool) {
        roundButton.isHidden=true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }


    override func numberOfSections(in tableView: UITableView) -> Int {
      
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return itemsArray.count+2
    }

    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row==0
        {
            return 269
        }
        else if indexPath.row==1
        {
            return 65
        }
        else if indexPath.row>1
        {
            return 160
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=UITableViewCell()
        if indexPath.row==0
        {
        let cell = tableView.dequeueReusableCell(withIdentifier: "profileCell") as! MainTableViewCell
            cell.imageCollection.delegate=self
            cell.imageCollection.dataSource=self
            cell.imageCollection.tag=indexPath.row
            cell.imageCollection.reloadData()
            return cell
        }
        if indexPath.row==1
        {
            let cell=tableView.dequeueReusableCell(withIdentifier: "collectionCell") as! TableViewCellCollection
            cell.collectionView.delegate=self
            cell.collectionView.dataSource=self
            cell.collectionView.tag=indexPath.row
            cell.collectionView.reloadData()
            return cell
        }
        if indexPath.row>1
        {
            let cell=tableView.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath) as! ItemDetailsCell
            print(itemNamesArr)
           cell.itemImage.image=itemsArray[indexPath.row-2]
            cell.itemName.text=itemNamesArr[indexPath.row-2]
            cell.itemCost.text="Rs."+itemCosts[indexPath.row-2]
            return cell
        }
        // Configure the cell...

        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView.tag==0
        {
            return imagesArr.count
        }
        else if collectionView.tag==1
        {
            return labelArr.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=UICollectionViewCell()
        if collectionView.tag==0
        {
            let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "image", for: indexPath) as! ImageCollectionViewCell
            let myImage=UIImageView(frame: CGRect(x: 0, y: 0, width: 374, height: 261))
            myImage.image=imagesArr[indexPath.row]
            cell.contentView.addSubview(myImage)
            return cell
        }
        if collectionView.tag==1
        {
        let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "collection", for: indexPath) as! LabelCollectionCell
            cell.myLabel.text=labelArr[indexPath.row]
        
            return cell
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView.tag==1
        {
            if indexPath.row==0
            {
                itemsArray=imagesArr
                itemNamesArr=imagesNames
                itemCosts=imagesCosts
                tableView.reloadData()
            }
            
            if indexPath.row==1
            {
                itemsArray=drinksArr
                itemNamesArr=drinkNames
                itemCosts=drinkPrices
                print(itemNamesArr)
                tableView.reloadData()
            }
            if indexPath.row==2
            {
                itemsArray=pizzaArr
                itemNamesArr=pizzaNames
                itemCosts=pizzaPrices
                tableView.reloadData()
            }
            if indexPath.row==3
            {
                itemsArray=fruitArr
                itemNamesArr=fruitName
                itemCosts=fruitPrice
                  tableView.reloadData()
            }
        }
    }
    

}
