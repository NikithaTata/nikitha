//
//  ImageCollectionViewCell.swift
//  RenewinTask
//
//  Created by brn.developers on 5/14/18.
//  Copyright © 2018 brn.developers. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
}
